package com.tejait.springbootb4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springbootb4Application {

	public static void main(String[] args) {
		SpringApplication.run(Springbootb4Application.class, args);
	}

}
