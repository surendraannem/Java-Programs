package com.tejait.springbootb4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Springbootb4ApplicationTests {

	@Test
	void contextLoads() {
	}

}
