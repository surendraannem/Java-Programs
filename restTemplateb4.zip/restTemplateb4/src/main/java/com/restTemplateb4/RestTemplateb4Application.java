package com.restTemplateb4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RestTemplateb4Application {

	public static void main(String[] args) {
		SpringApplication.run(RestTemplateb4Application.class, args);
	}

}
